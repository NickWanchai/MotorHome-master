package com.example.demo.uiController;

import com.example.demo.model.SystemController;
import com.example.demo.model.Autocamper;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class AutoController {

    private SystemController sController = new SystemController();

    @GetMapping("/autocamper")
    public String autocamper(Model model){
        model.addAttribute("autocampers", sController.getAllAutocampers());
        return "autocamper";
    }

    @GetMapping("addAuto")
    public String addAuto(Model model){
        model.addAttribute("autocamper", new Autocamper());
        return "addAuto";
    }

    @PostMapping("/addAuto")
    public String addAuto(HttpServletRequest request){
        String model = request.getParameter("model");
        String brand = request.getParameter("brand");
        int size = Integer.parseInt(request.getParameter("size"));
        int age = Integer.parseInt(request.getParameter("age"));
        int price = Integer.parseInt(request.getParameter("price"));
        String fuel = request.getParameter("fuelType");
        String tow = request.getParameter("towHitch");
        String available = request.getParameter("available");
        Autocamper autocamper = new Autocamper(model, brand, size, age, price, fuel, tow, available);
        sController.addAutocamper(autocamper);
        return "redirect:/autocamper";
    }


}
