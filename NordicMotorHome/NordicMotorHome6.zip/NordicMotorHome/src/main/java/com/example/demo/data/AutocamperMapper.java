package com.example.demo.data;

import com.example.demo.model.Autocamper;
import com.example.demo.model.Rental;

import java.sql.*;
import java.util.ArrayList;

public class AutocamperMapper {

    public void addAutocamper(Autocamper autocamper){
        try{
            Connection connection = DBConnectionManager.getConnection();
            String SQL = "INSERT INTO autocamper VALUES(DEFAULT, ?,?,?,?,?,?,?,?)";
            PreparedStatement ps = connection.prepareStatement(SQL, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, autocamper.getModel());
            ps.setString(2, autocamper.getBrand());
            ps.setInt(3, autocamper.getSize());
            ps.setInt(4, autocamper.getAge());
            ps.setInt(5, autocamper.getPrice());
            ps.setString(6, autocamper.getFuelType());
            ps.setString(7, autocamper.getTowHitch());
            ps.setString(8, autocamper.getAvailable());
            ps.executeUpdate();

        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    public ArrayList<Autocamper> getAllAutocampers(){
        ArrayList<Autocamper> auto = new ArrayList<>();

        try{
            Connection connection = DBConnectionManager.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM autocamper";
            ResultSet rs = statement.executeQuery(sql);

            int id;
            String model;
            String brand;
            int size;
            int age;
            int price;
            String fuelType;
            String towHitch;
            String available;
            Autocamper autocamper;

            while(rs.next()){
                id = rs.getInt("autocamper_Id");
                model = rs.getString("model");
                brand = rs.getString("brand");
                size = rs.getInt("size");
                age = rs.getInt("age");
                price = rs.getInt("price");
                fuelType = rs.getString("fuel_type");
                towHitch = rs.getString("tow_hitch");
                available = rs.getString("available");

                autocamper = new Autocamper(id, model, brand, size, age, price, fuelType, towHitch, available);
                auto.add(autocamper);
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return auto;
    }

    public Autocamper findAutocamper(int idSearch){
        Autocamper autocamper = null;

        try{
            Connection connection = DBConnectionManager.getConnection();
            Statement statement = connection.createStatement();
            String sql = "SELECT * FROM autocamper";
            ResultSet rs = statement.executeQuery(sql);

            int id;
            String model;
            String brand;
            int size;
            int age;
            int price;
            String fuelType;
            String towHitch;
            String available;

            while(rs.next()){
                id = rs.getInt("autocamper_Id");
                model = rs.getString("com/example/demo/model");
                brand = rs.getString("brand");
                size = rs.getInt("size");
                age = rs.getInt("age");
                price = rs.getInt("price");
                fuelType = rs.getString("fuel_type");
                towHitch = rs.getString("tow_hitch");
                available = rs.getString("available");

                if(id == idSearch){
                    return new Autocamper(id, model, brand, size, age, price, fuelType, towHitch, available);
                }
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return autocamper;
    }

    public void deleteAutocamper(int id){
        try{
            Connection connection = DBConnectionManager.getConnection();
            String sql = "DELETE FROM autocamper WHERE autocamperId = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1,id);
            preparedStatement.executeUpdate();

        }catch(SQLException e){
            e.printStackTrace();
        }
    }




}
