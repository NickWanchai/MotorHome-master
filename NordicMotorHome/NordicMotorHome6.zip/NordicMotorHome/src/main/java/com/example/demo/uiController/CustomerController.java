package com.example.demo.uiController;


import com.example.demo.model.SystemController;
import com.example.demo.model.Customer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;


@Controller
public class CustomerController{

    private SystemController sController = new SystemController();

    @GetMapping("/customers")
    public String customers(Model model){
        model.addAttribute("customers", sController.getAllCustomers());
        return "customers";
    }

    @GetMapping("/add")
    public String add(Model model){
        //klargør tomt objekt, som addCustomer.html skal bruge
        model.addAttribute("customer", new Customer());
        return "addCustomer";
    }

    @PostMapping("/add")
    public String add(HttpServletRequest request) {
        String fn = request.getParameter("firstName");
        String ln = request.getParameter("lastName");
        String city = request.getParameter("city");
        String age = request.getParameter("age");
        String split[] = age.split("-");
        int year = Integer.parseInt(split[0]);
        int month = Integer.parseInt(split[1]);
        int day = Integer.parseInt(split[2]);
        LocalDate age2 = LocalDate.of(year, month, day);
        String email = request.getParameter("email");
        int zipCode = Integer.parseInt(request.getParameter("zipCode"));
        String adress = request.getParameter("adress");
        int phonenumber = Integer.parseInt(request.getParameter("phonenumber"));
        Customer customer = new Customer(fn,ln, city, age2, email, zipCode, adress, phonenumber);
        sController.addCustomer(customer);
        return "redirect:/customers";
    }


    @GetMapping("/delete")
    public String delete(Model model){
        model.addAttribute("customers", sController.getAllCustomers());
        return "deleteCustomer";
    }


    @GetMapping("/verifyDelete")
    public String verifyDelete(@RequestParam("id") int id, Model model) {
        model.addAttribute("customer", sController.findCustomer(id));
        return "verifyDelete";
    }

    @PostMapping("/verifyDelete")
    public String verifyDelete(HttpServletRequest request) {
        String id = request.getParameter("id");
        sController.deleteCustomer(Integer.parseInt(id));
        return "redirect:/";
    }


}
