package com.example.demo.uiController;

import com.example.demo.model.SystemController;
import com.example.demo.exceptions.RentAutocamperException;
import com.example.demo.model.Rental;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
public class RentalController {

    private SystemController sController = new SystemController();


    @GetMapping("/addRental")
    public String addRental(Model model) {
        //klargør tomt objekt, som addCustomer.html skal bruge
        model.addAttribute("rental", new Rental());
        model.addAttribute("autocampers", sController.getAllAutocampers());
        model.addAttribute("customers", sController.getAllCustomers());
        return "addRental";
    }

    @PostMapping("/addRental")
    public String addRental(HttpServletRequest request) throws RentAutocamperException {

        int customerId = Integer.parseInt(request.getParameter("customerId"));
        int autocamperId = Integer.parseInt(request.getParameter("autocamperId"));
        Rental rental = new Rental(customerId, autocamperId);


        if(sController.checkForAvailability(autocamperId)) {
            throw new RentAutocamperException("Er allerede udlejet!");
        }
        if(!sController.findAutocamperId(autocamperId)){
            throw new RentAutocamperException("findes ikke");
        }
        if(sController.checkForAvailability2(customerId)) {
            throw new RentAutocamperException("Udlejer allerede!");
        }
        if(!sController.findCustomerId(customerId)) {
            throw new RentAutocamperException("Kunde findes ikke");
        }else{
            sController.addRental(rental);
                return "redirect:/rentals";
            }
    }


    @GetMapping("/rentals")
    public String rentals(Model model){
        model.addAttribute("rentals", sController.getAllRentals());
        return "rentals";
    }

    @ExceptionHandler(RentAutocamperException.class)
    public String rentAutocamperException(Model model, Exception exception){
        model.addAttribute("message", exception.getMessage());
        return "rentAutocamperException";
    }


}
