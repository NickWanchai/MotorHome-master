package com.example.demo.exceptions;

public class RentAutocamperException extends Exception {
    public RentAutocamperException(String message){
        super(message);
    }
}
