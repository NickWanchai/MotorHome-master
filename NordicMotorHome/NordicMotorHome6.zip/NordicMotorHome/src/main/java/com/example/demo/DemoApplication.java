package com.example.demo;

import com.example.demo.data.AutocamperMapper;
import com.example.demo.data.CustomerMapper;
import com.example.demo.model.Customer;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;

@SpringBootApplication
public class DemoApplication {

    public static void main(String[] args) throws NullPointerException {
        SpringApplication.run(DemoApplication.class, args);

        CustomerMapper cM = new CustomerMapper();
        AutocamperMapper aC = new AutocamperMapper();


        Customer customer = new Customer("Nick", "Larsen", "haslev ", LocalDate.of(1993,11,15),"Nick@Nick.dk",2860,"hvej 2", 44755888);
        //cM.addCustomer(customer);

       /* Autocamper autocamper = new Autocamper("BOBALOO", "FORD", 6, 1993, 100, "benz", "yes", "yes");
        aC.addAutocamper(autocamper);
        */


        // System.out.println(cM.getAllCustomers());



    }

}
