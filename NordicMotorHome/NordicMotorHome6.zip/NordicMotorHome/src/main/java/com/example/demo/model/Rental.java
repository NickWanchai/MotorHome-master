package com.example.demo.model;

public class Rental {

    private int rentalId;
    private int customerId;
    private int autocamperId;

    public Rental(int rentalId, int customerId, int autocamperId) {
        this.rentalId = rentalId;
        this.customerId = customerId;
        this.autocamperId = autocamperId;
    }

    public Rental(int customerId, int autocamperId) {
        this.customerId = customerId;
        this.autocamperId = autocamperId;
    }

    public Rental() {
    }

    public int getRentalId() {
        return rentalId;
    }

    public void setRentalId(int rentalId) {
        this.rentalId = rentalId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getAutocamperId() {
        return autocamperId;
    }

    public void setAutocamperId(int autocamperId) {
        this.autocamperId = autocamperId;
    }

    @Override
    public String toString() {
        return "Rental{" +
                "rentalId=" + rentalId +
                ", customerId=" + customerId +
                ", autocamperId=" + autocamperId +
                '}';
    }
}
