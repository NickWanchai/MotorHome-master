package com.example.demo.model;

public class Autocamper {
    private int id;
    private String model;
    private String brand;
    private int size;
    private int age;
    private int price;
    private String fuelType;
    private String towHitch;
    private String available;

    public Autocamper(int id, String model, String brand, int size, int age, int price, String fuelType, String towHitch, String available) {
        this.id = id;
        this.model = model;
        this.brand = brand;
        this.size = size;
        this.age = age;
        this.price = price;
        this.fuelType = fuelType;
        this.towHitch = towHitch;
        this.available = available;
    }

    public Autocamper(String model, String brand, int size, int age, int price, String fuelType, String towHitch, String available) {
        this.model = model;
        this.brand = brand;
        this.size = size;
        this.age = age;
        this.price = price;
        this.fuelType = fuelType;
        this.towHitch = towHitch;
        this.available = available;
    }

    public Autocamper(){
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public void setTowHitch(String towHitch) {
        this.towHitch = towHitch;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public int getId() {
        return id;
    }

    public String getModel() {
        return model;
    }

    public String getBrand() {
        return brand;
    }

    public int getSize() {
        return size;
    }

    public int getAge() {
        return age;
    }

    public int getPrice() {
        return price;
    }

    public String getFuelType() {
        return fuelType;
    }

    public String getTowHitch() {
        return towHitch;
    }

    public String getAvailable() {
        return available;
    }

    @Override
    public String toString() {
        return "Autocamper{" +
                "id=" + id +
                ", com.example.demo.model='" + model + '\'' +
                ", brand='" + brand + '\'' +
                ", size=" + size +
                ", age=" + age +
                ", price=" + price +
                ", fuelType='" + fuelType + '\'' +
                ", towHitch='" + towHitch + '\'' +
                ", available='" + available + '\'' +
                '}';
    }
}
